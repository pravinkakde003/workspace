package com.exceptionaire.denso.Utils;

public interface ActivityCallbackInterface {

	public void getResultBack(String result);
	
}
